<template>
  <div class="flex min-w-0 w-full flex-col flex-grow">
    <div class="room-page">
      <section class="room-panel">
        <header class="room-panel__header">
          <div class="room-panel__title">
            <PlaceIcon :name="room?.icon" size="md" />
            <div class="room-panel__copy">
              <span class="room-panel__eyebrow">Room</span>
              <h1>{{ room?.name || 'Room' }}</h1>
            </div>
          </div>

          <div class="room-panel__actions">
            <Skeleton v-if="isLoading" width="8rem" height="2rem" />
            <template v-else-if="!isReadOnly">
              <Button label="Edit" icon="pi pi-pencil" severity="secondary" variant="text" @click="editRoomDialog = true" />
              <Button label="Delete" icon="pi pi-trash" severity="danger" variant="text" @click="deleteRoom" />
            </template>
          </div>
        </header>

        <div class="room-panel__content">
          <NuxtPage />
        </div>
      </section>
    </div>

    <edit-room-dialog v-if="!isReadOnly" v-model="editRoomDialog" :envId="envId" :roomId="roomId" @refresh="refreshRoom" />
  </div>
</template>

<script setup lang="ts">
definePageMeta({ name: 'room', layout: 'dashboard', requiresAuth: true })

import { computed, onMounted, provide, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useEnvironmentStore } from "@/store/environmentStore";
import { getRoom, removeRoom as deleteRoomApi } from "@/services/apiService";
import type { Environment } from "@/types/environment";
import type { Room } from "@/types/room";
import Button from 'primevue/button';
import Skeleton from 'primevue/skeleton';
import EditRoomDialog from "@/components/room/EditRoomDialog.vue";
import PlaceIcon from "@/components/common/PlaceIcon.vue";
import { useConfirm } from "primevue/useconfirm";
import { useToast } from "primevue/usetoast";
import { isReadOnlyRole } from "@/utils/roomAccess";

const route = useRoute();
const router = useRouter();
const envId = Number(route.params.envId);
const roomId = Number(route.params.roomId);
const dataLoadTimeoutMs = 5000;

const environmentStore = useEnvironmentStore();
const editRoomDialog = ref(false);
const isRefreshing = ref(false);
const environmentData = ref<Environment | null>(null);
const roomData = ref<Room | null>(null);
const environmentPending = ref(true);
const roomPending = ref(true);
const confirm = useConfirm();
const toast = useToast();

if (route.name === "room") {
  await navigateTo({ name: "room-parameters", params: { envId, roomId } }, { replace: true });
}

const environment = computed(() => environmentData.value ?? null);
const room = computed(() => roomData.value ?? null);
const isLoading = computed(() => environmentPending.value || roomPending.value || isRefreshing.value);
const isReadOnly = computed(() => !environment.value || isReadOnlyRole(environment.value.role));

provide("roomReadOnly", isReadOnly);

const withTimeout = async <T,>(promise: Promise<T>, timeoutMs: number): Promise<T> => {
  let timeoutId: ReturnType<typeof setTimeout> | undefined;

  return Promise.race([
    promise.finally(() => {
      if (timeoutId) clearTimeout(timeoutId);
    }),
    new Promise<T>((_, reject) => {
      timeoutId = setTimeout(() => reject(new Error("Room request timed out")), timeoutMs);
    }),
  ]);
};

const loadEnvironment = async (forceRefresh = false) => {
  environmentPending.value = true;
  try {
    environmentData.value = await withTimeout(
      environmentStore.fetchEnvironment(envId, forceRefresh),
      dataLoadTimeoutMs,
    );
  } catch {
    environmentData.value = null;
  } finally {
    environmentPending.value = false;
  }
};

const loadRoom = async () => {
  roomPending.value = true;
  try {
    roomData.value = await withTimeout(getRoom(envId, roomId), dataLoadTimeoutMs);
  } catch {
    roomData.value = null;
  } finally {
    roomPending.value = false;
  }
};

const refreshRoom = async () => {
  isRefreshing.value = true;
  try {
    await loadEnvironment(true);
    await loadRoom();
  } finally {
    isRefreshing.value = false;
  }
}

onMounted(async () => {
  await loadEnvironment();
  await loadRoom();
});

const deleteRoom = async () => {
  if (isReadOnly.value) return;

  confirm.require({
        message: 'Are you sure you want to delete this room?',
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        rejectProps: {
          label: 'Cancel',
          severity: 'secondary',
          outlined: true
        },
        acceptProps: {
          label: 'Delete',
          severity: 'danger'
        },
        accept: async () => {
          await deleteRoomApi(envId, roomId);
          router.push({ name: 'environment-rooms', params: { envId } });
          toast.add({ severity: 'success', summary: 'Success', detail: 'Room successfully deleted', life: 3000 });
        },
      });
}
</script>

<style scoped>
.room-page {
  display: flex;
  flex: 1;
  height: 100%;
  min-height: 0;
  min-width: 0;
  width: 100%;
}

.room-panel {
  background: var(--app-surface);
  border: 1px solid var(--app-border);
  border-radius: var(--app-radius);
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
  min-width: 0;
  overflow: hidden;
  width: 100%;
}

.room-panel__header {
  align-items: center;
  background: var(--app-surface);
  border-bottom: 1px solid var(--app-border);
  display: flex;
  flex: 0 0 auto;
  gap: 12px;
  justify-content: space-between;
  min-width: 0;
  padding: 10px var(--app-panel-padding);
}

.room-panel__title {
  align-items: center;
  display: flex;
  gap: 12px;
  min-width: 0;
}

.room-panel__copy {
  min-width: 0;
}

.room-panel__eyebrow {
  color: var(--app-muted);
  display: block;
  font-family: var(--app-mono);
  font-size: 0.68rem;
  font-weight: 600;
  line-height: 1rem;
  text-transform: uppercase;
}

.room-panel h1 {
  color: var(--app-text-strong);
  font-size: 1rem;
  font-weight: 800;
  line-height: 1.35rem;
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.room-panel__actions {
  align-items: center;
  display: flex;
  gap: var(--app-gap-xs);
  flex: 0 0 auto;
}

.room-panel__actions :deep(.p-button) {
  min-height: var(--app-compact-control-height);
  padding-block: 0.34rem;
}

.room-panel__content {
  display: flex;
  flex: 1;
  min-height: 0;
  min-width: 0;
  overflow: auto;
  padding: var(--app-panel-padding);
  scrollbar-gutter: stable;
}

@media (max-width: 520px) {
  .room-panel__header {
    align-items: flex-start;
    flex-direction: column;
  }

  .room-panel__actions {
    grid-template-columns: 1fr 1fr;
    width: 100%;
  }

  .room-panel__actions :deep(.p-button) {
    flex: 1 1 0;
  }

  .room-panel__content {
    padding: var(--app-gap-sm);
  }
}
</style>
