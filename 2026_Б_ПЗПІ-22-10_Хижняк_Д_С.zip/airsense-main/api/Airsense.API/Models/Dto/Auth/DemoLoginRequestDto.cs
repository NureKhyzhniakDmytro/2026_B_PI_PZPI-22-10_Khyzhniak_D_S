namespace Airsense.API.Models.Dto.Auth;

public class DemoLoginRequestDto
{
    public string Username { get; set; }

    public string Password { get; set; }
}
