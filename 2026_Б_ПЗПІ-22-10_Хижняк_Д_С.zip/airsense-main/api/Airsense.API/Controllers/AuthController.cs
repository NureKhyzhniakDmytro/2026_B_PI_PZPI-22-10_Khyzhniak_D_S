using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Airsense.API.Models.Dto.Auth;
using Airsense.API.Models.Entity;
using Airsense.API.Repository;
using Airsense.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace Airsense.API.Controllers;

[ApiController]
[Route("auth")]
[Authorize]
public class AuthController(
    IUserRepository userRepository,
    IEnvironmentRepository environmentRepository,
    IAuthService authService,
    IConfiguration configuration) : ControllerBase
{
    private const string DemoEnvironmentName = "North Line Microclimate Test Facility";
    private const string DemoOwnerEmail = "khijnyak.dima@gmail.com";
    private const string DemoUsername = "demo";
    private const string DemoPassword = "demo";
    private const string DemoUid = "demo-user";
    private const string DemoEmail = "demo@airsense.local";
    private const string DemoName = "Demo Shift Operator";

    [AllowAnonymous]
    [HttpPost("demo")]
    public async Task<IActionResult> DemoLogin([FromBody] DemoLoginRequestDto request)
    {
        if (!string.Equals(request.Username?.Trim(), DemoUsername, StringComparison.Ordinal)
            || !string.Equals(request.Password, DemoPassword, StringComparison.Ordinal))
            return Unauthorized(new { message = "Invalid demo credentials" });

        var user = await userRepository.CreateAsync(new User
        {
            Uid = DemoUid,
            Email = DemoEmail,
            Name = DemoName
        });

        await environmentRepository.AddMemberByEnvironmentNameIfMissingAsync(DemoEnvironmentName, user.Id, "user");

        return Ok(new
        {
            token = CreateDemoToken(user)
        });
    }

    [HttpPost]
    public async Task<IActionResult> Login([FromBody] AuthRequestDto request)
    {
        var uid = User.FindFirstValue(ClaimTypes.NameIdentifier);
        var email = User.FindFirstValue(ClaimTypes.Email);
        if (string.IsNullOrWhiteSpace(uid) || string.IsNullOrWhiteSpace(email))
            return BadRequest(new { message = "You are not registered" });

        var name = User.FindFirstValue("name") ?? email;
        var user = await userRepository.GetByUidAsync(uid);
        var isCreated = false;
        if (user is null)
        {
            var existingEmailUser = await userRepository.GetByEmailAsync(email);
            if (existingEmailUser is not null)
            {
                existingEmailUser.Uid = uid;
                existingEmailUser.Name = name;
                existingEmailUser.Email = email;
                user = await userRepository.CreateWithIdAsync(existingEmailUser);
            }
            else
            {
                user = new User
                {
                    Name = name,
                    Email = email,
                    Uid = uid
                };
                user = await userRepository.CreateAsync(user);
                isCreated = true;
            }
        }

        var tokenId = User.FindFirstValue("id");
        if (tokenId != user.Id.ToString())
        {
            var result = await authService.SetIdAsync(uid, user.Id);
            if (!result)
                return StatusCode(500, new { Message = "Failed to set id" });
        }

        if (request.NotificationToken is not null)
            await userRepository.SetNotificationTokenAsync(uid, request.NotificationToken);

        if (string.Equals(email, DemoOwnerEmail, StringComparison.OrdinalIgnoreCase))
            await environmentRepository.UpsertMemberByEnvironmentNameAsync(DemoEnvironmentName, user.Id, "owner");
        else
            await environmentRepository.AddMemberByEnvironmentNameIfMissingAsync(DemoEnvironmentName, user.Id, "user");

        return isCreated ? StatusCode(201) : NoContent();
    }

    private string CreateDemoToken(User user)
    {
        var signingKey = configuration["DemoAuth:SigningKey"] ?? "airsense-demo-auth-local-development-key";
        var issuer = configuration["DemoAuth:Issuer"] ?? "airsense-demo";
        var audience = configuration["DemoAuth:Audience"] ?? "airsense-web";
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var now = DateTime.UtcNow;

        var token = new JwtSecurityToken(
            issuer: issuer,
            audience: audience,
            claims:
            [
                new Claim("id", user.Id.ToString()),
                new Claim(ClaimTypes.NameIdentifier, user.Uid),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim("email", user.Email),
                new Claim("name", user.Name)
            ],
            notBefore: now,
            expires: now.AddHours(12),
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
